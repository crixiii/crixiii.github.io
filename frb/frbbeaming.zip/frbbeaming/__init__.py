"""Observed burst-energy distributions for different beam models and intrinsic energy distributions.

Conventions: theta is the observer angle from the beam axis with p(theta) = sin(theta)/2; g = E_obs/E;
"pdf_ln" is a PDF per unit ln E_obs (plots multiply by ln 10 for per dex); power-law index alpha > 0
means pdf ~ E**-(alpha+1).
"""

from .analysis import bimodality, bimodality_selftest, fit_tail_slope, mle_powerlaw
from .beams import Beam, GaussianBeam, IsotropicBeam, RelativisticBeam, build_beams
from .config import Config
from .distributions import BrokenPowerLaw, Intrinsic, LogNormal, PowerLaw, SingleEnergy, build_distributions
from .simulation import Simulation


def __getattr__(name):
    """Plotter and Validator need matplotlib, so import them only when asked for."""
    if name == "Plotter":
        from .plotting import Plotter
        return Plotter
    if name == "Validator":
        from .validation import Validator
        return Validator
    raise AttributeError(name)
