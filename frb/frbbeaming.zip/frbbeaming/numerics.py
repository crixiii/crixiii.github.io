from functools import lru_cache

import numpy as np

trapz = getattr(np, "trapezoid", None) or np.trapz
LN10 = np.log(10.0)


@lru_cache(maxsize=None)
def _gauss_legendre(n):
    return np.polynomial.legendre.leggauss(n)


def gauss_panels(edges, n=24):
    nodes, weights = _gauss_legendre(n)
    lo, hi = edges[:-1, None], edges[1:, None]
    return 0.5 * (hi - lo) * nodes + 0.5 * (hi + lo), 0.5 * (hi - lo) * weights


def integrate_theta(f, a, b, breaks, n=24):
    breaks = np.asarray(breaks, float)
    edges = np.concatenate([[a], breaks[(breaks > a) & (breaks < b)], [b]])
    fine = np.concatenate([np.linspace(lo, hi, 5)[:-1] for lo, hi in zip(edges[:-1], edges[1:])] + [[b]])
    x, w = gauss_panels(fine, n)
    return np.sum(w * f(x))


def sample_theta(rng, n):
    """Observer angles of isotropically oriented jets: p(theta) = sin(theta)/2."""
    return np.arccos(rng.uniform(-1, 1, n))
