import numpy as np

from .analysis import bimodality
from .beams import build_beams
from .config import Config
from .distributions import build_distributions


class Simulation:
    """Holds a Config plus every beam and intrinsic distribution.

    Beams are looked up by label ("Isotropic", "Gaussian", "Gaussian & Plateau", "Relativistic",
    "R-PL", "R-G") and distributions by name ("single", "lognormal", "powerlaw"); objects work too.
    """

    def __init__(self, cfg=None):
        self.cfg = cfg or Config()
        self.beams = build_beams(self.cfg)
        self.dists = build_distributions(self.cfg)

    def add_beam(self, beam):
        self.beams[beam.label] = beam

    def add_distribution(self, dist):
        self.dists[dist.name] = dist

    def _beam(self, beam):
        return self.beams[beam] if isinstance(beam, str) else beam

    def _dist(self, dist):
        return self.dists[dist] if isinstance(dist, str) else dist

    def pdf_ln(self, beam, dist, e_grid=None):
        """Observed PDF per unit ln E_obs. Returns (e_grid, pdf) when no grid is given."""
        beam, dist = self._beam(beam), self._dist(dist)
        given = e_grid is not None
        grid = np.asarray(e_grid, float) if given else beam.default_grid(self.cfg)
        p = beam.observed_pdf_ln(dist, grid)
        return p if given else (grid, p)

    def single_energy_pdf(self, beam):
        return self._beam(beam).single_energy_pdf(self.cfg.e0)

    def sample(self, beam, dist, n=None, rng=None, seed=0):
        rng = rng or np.random.default_rng(seed)
        return self._beam(beam).sample(self._dist(dist), rng, n or self.cfg.n_sim)

    def observed_log_energies(self, beam, dist, n=None, rng=None, seed=0, r_max=None, complete_only=True):
        """log10(E_obs) of a simulated population, optionally only above the incompleteness cut E0*g(r_max)."""
        beam = self._beam(beam)
        log_e = np.log10(np.maximum(self.sample(beam, dist, n, rng, seed), 1e-300))
        if complete_only:
            g_cut = beam.g_cut(self.cfg.r_max if r_max is None else r_max)
            log_e = log_e[log_e > np.log10(self.cfg.e0 * max(g_cut, 1e-300))]
        return log_e

    def bimodality(self, beam, dist, n=None, seed=0, jitter=0.01, **kw):
        """Returns the bimodality result dict, or None if the sample is degenerate."""
        rng = np.random.default_rng(seed)
        log_e = self.observed_log_energies(beam, dist, n, rng)
        if len(log_e) < 100 or np.ptp(log_e) == 0:
            return None
        log_e = log_e + rng.normal(0, jitter, len(log_e))
        return bimodality(log_e, seed=seed, **kw)

    def bimodality_table(self, seed=0, verbose=True, **kw):
        rows = []
        for b_label, beam in self.beams.items():
            for d_name, dist in self.dists.items():
                r = self.bimodality(beam, dist, seed=seed, **kw)
                if r is None:
                    if verbose:
                        print(f"{b_label:20s} {d_name:10s} degenerate, skipped")
                    continue
                rows.append(dict(beam=b_label, dist=d_name, **r))
                if verbose:
                    print(f"{b_label:20s} {d_name:10s} p_dip={r['p_dip']:.3f} dBIC={r['dbic']:9.1f} "
                          f"D={r['D']:.2f} w_min={r['w_min']:.2f} -> {r['bimodal']}")
        return rows
