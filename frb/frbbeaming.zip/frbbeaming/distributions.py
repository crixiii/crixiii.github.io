import numpy as np
from scipy import stats


class Intrinsic:
    """pdf and sf are per unit E; pdf_ln is per unit ln E (x = ln E). e_min is the hard lower edge of the support."""

    name = "intrinsic"
    label = "Intrinsic"
    scale = 1.0
    e_min = None

    def pdf(self, e):
        raise NotImplementedError

    def sf(self, e):
        raise NotImplementedError

    def sample(self, rng, n):
        raise NotImplementedError

    def e_range(self):
        """(lo, hi) in units of scale, spanning the bulk of the distribution."""
        return 0.02, 30.0

    def pdf_ln(self, x):
        e = np.exp(x)
        return e * self.pdf(e)


class SingleEnergy(Intrinsic):
    name, label = "single", "Single energy"

    def __init__(self, e0):
        self.scale = e0

    def sample(self, rng, n):
        return np.full(n, self.scale)


class LogNormal(Intrinsic):
    name, label = "lognormal", "Log-normal"

    def __init__(self, e0, shape=1.0):
        self.scale, self.shape = e0, shape

    def pdf(self, e):
        return stats.lognorm.pdf(np.asarray(e, float) / self.scale, self.shape) / self.scale

    def sf(self, e):
        return stats.lognorm.sf(np.asarray(e, float) / self.scale, self.shape)

    def sample(self, rng, n):
        return self.scale * rng.lognormal(0, self.shape, n)

    def pdf_ln(self, x):
        mu = np.log(self.scale)
        return np.exp(-((x - mu) ** 2) / (2 * self.shape**2)) / (self.shape * np.sqrt(2 * np.pi))


class PowerLaw(Intrinsic):
    """pdf(E) = alpha/E0 * (E/E0)**-(alpha+1) for E >= E0."""

    name, label = "powerlaw", "Power-law"

    def __init__(self, e0, index=0.7):
        self.scale, self.index = e0, index
        self.e_min = e0

    def pdf(self, e):
        x = np.asarray(e, float) / self.scale
        return np.where(x >= 1, self.index * np.maximum(x, 1.0) ** (-self.index - 1), 0.0) / self.scale

    def sf(self, e):
        x = np.asarray(e, float) / self.scale
        return np.where(x >= 1, np.maximum(x, 1.0) ** (-self.index), 1.0)

    def sample(self, rng, n):
        return self.scale * (1 - rng.random(n)) ** (-1 / self.index)

    def e_range(self):
        return 1.0, 1e6

    def powerlaw_components(self):
        """(weight, index) pairs: pdf per unit ln E is sum(weight * index * (E/e_min)**-index)."""
        return [(1.0, self.index)]

    def pdf_ln(self, x):
        d = x - np.log(self.scale)
        return np.where(d >= 0, self.index * np.exp(-self.index * np.maximum(d, 0.0)), 0.0)


class BrokenPowerLaw(Intrinsic):
    """Two power laws crossing at e_break, for E >= e_min. With x = E/e_min and
    a = (e_break/e_min)**(alpha2-alpha1) * alpha1/alpha2: S(x) = (x**-alpha1 + a * x**-alpha2) / (1 + a)."""

    name, label = "broken_powerlaw", "Broken power-law"

    def __init__(self, e_min, alpha1, alpha2, e_break):
        self.scale, self.e_min = e_min, e_min
        self.a1, self.a2, self.e_break = alpha1, alpha2, e_break
        self._a = (e_break / e_min) ** (alpha2 - alpha1) * alpha1 / alpha2
        self._lnx = np.linspace(0.0, np.log(1e40), 40_000)
        self._lns = np.log(self._s(np.exp(self._lnx)))

    @classmethod
    def from_differential(cls, e_min, gamma1, gamma2, e_break):
        """Original all_funcs.py convention: pdf ~ E**gamma with gamma < -1, so alpha = -gamma - 1."""
        return cls(e_min, -gamma1 - 1, -gamma2 - 1, e_break)

    def _s(self, x):
        return (x**-self.a1 + self._a * x**-self.a2) / (1 + self._a)

    def pdf(self, e):
        x = np.asarray(e, float) / self.scale
        xs = np.maximum(x, 1.0)
        dens = (self.a1 * xs ** (-self.a1 - 1) + self._a * self.a2 * xs ** (-self.a2 - 1)) / (1 + self._a)
        return np.where(x >= 1, dens, 0.0) / self.scale

    def sf(self, e):
        x = np.asarray(e, float) / self.scale
        return np.where(x >= 1, self._s(np.maximum(x, 1.0)), 1.0)

    def powerlaw_components(self):
        return [(1 / (1 + self._a), self.a1), (self._a / (1 + self._a), self.a2)]

    def sample(self, rng, n):
        ln_w = np.log(1 - rng.random(n))
        return self.scale * np.exp(np.interp(ln_w, self._lns[::-1], self._lnx[::-1]))

    def e_range(self):
        return 1.0, 1e6


def build_distributions(cfg):
    dists = [SingleEnergy(cfg.e0), LogNormal(cfg.e0, cfg.lognorm_shape), PowerLaw(cfg.e0, cfg.pl_index),
             BrokenPowerLaw(cfg.e0, cfg.bpl_alpha1, cfg.bpl_alpha2, cfg.bpl_break)]
    return {d.name: d for d in dists}
