import numpy as np
from scipy.optimize import curve_fit


def bimodality(log_e, d_min=2.0, dbic_min=10.0, w_min=0.1, alpha=0.01, seed=0, dip_max_n=50_000, use_dip=True):
    """Is a sample of log10(E_obs) bimodal? All four criteria must pass:
    dip test p < alpha; 2-component GMM beats 1 by dBIC > dbic_min; Ashman's
    D = sqrt(2)|mu1-mu2| / sqrt(s1^2+s2^2) >= d_min; smaller component weight >= w_min.
    The dip test uses at most dip_max_n points (its p-value table is valid up to 72,000).
    use_dip=False skips the dip test (dip and p_dip are nan), e.g. where diptest cannot be installed.
    Needs scikit-learn, and diptest unless use_dip=False."""
    from sklearn.mixture import GaussianMixture

    x = np.asarray(log_e, float).reshape(-1, 1)
    g1 = GaussianMixture(1, n_init=5, random_state=seed).fit(x)
    g2 = GaussianMixture(2, n_init=5, random_state=seed).fit(x)
    dbic = g1.bic(x) - g2.bic(x)
    mu, var, w = g2.means_.ravel(), g2.covariances_.ravel(), g2.weights_
    D = np.sqrt(2) * abs(mu[0] - mu[1]) / np.sqrt(var.sum())
    dip, p = np.nan, np.nan
    if use_dip:
        from diptest import diptest

        xs = x.ravel()
        if len(xs) > dip_max_n:
            xs = np.random.default_rng(seed).choice(xs, dip_max_n, replace=False)
        dip, p = diptest(xs)
    dip_ok = (p < alpha) if use_dip else True
    return dict(dip=dip, p_dip=p, dbic=dbic, D=D, w_min=w.min(), means=mu, stds=np.sqrt(var), weights=w,
                bimodal=bool(dip_ok and (dbic > dbic_min) and (D >= d_min) and (w.min() >= w_min)))


def bimodality_selftest(n=20_000, seed=0):
    rng = np.random.default_rng(seed)
    cases = {
        "unimodal gaussian": rng.normal(0, 1, n),
        "unimodal skewed": rng.gamma(2.0, 1.0, n),
        "bimodal, D=4": np.concatenate([rng.normal(-2, 1, n // 2), rng.normal(2, 1, n // 2)]),
        "bimodal, D~1 (merge)": np.concatenate([rng.normal(-0.5, 1, n // 2), rng.normal(0.5, 1, n // 2)]),
        "bimodal, 2% minor": np.concatenate([rng.normal(-3, 1, int(0.98 * n)), rng.normal(3, 1, int(0.02 * n))]),
    }
    for name, x in cases.items():
        r = bimodality(x)
        print(f"{name:22s} dip={r['dip']:.4f} p={r['p_dip']:.3f} dBIC={r['dbic']:8.1f} "
              f"D={r['D']:.2f} w_min={r['w_min']:.2f} -> bimodal={r['bimodal']}")


def mle_powerlaw(energies):
    """Maximum-likelihood differential index gamma (pdf ~ E**gamma) and its 1-sigma error
    (James+2019, Crawford+1970). The cumulative index is alpha = -gamma - 1."""
    e = np.asarray(energies, float)
    n = len(e)
    gamma = -(n - 1) / np.sum(np.log(e / e.min())) - 1
    return gamma, abs(gamma) / np.sqrt(n - 2)


def fit_tail_slope(x, y, p0=(-1.0, 0.0), stride=14, from_peak=True):
    """Fit y = m*x + c to a log-log PDF tail, thinned to every stride-th point past the peak. Returns (m, c)."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    ok = ~np.isinf(y)
    x, y = x[ok], y[ok]
    if from_peak:
        i = np.argmax(y)
        x, y = x[i::stride], y[i::stride]
    popt, _ = curve_fit(lambda xx, m, c: m * xx + c, x, y, p0=p0)
    return popt
