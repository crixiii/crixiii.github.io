from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class Config:
    """Every model, numerical and figure parameter in one place."""

    e0: float = 1e40  # erg
    lognorm_shape: float = 1.0
    pl_index: float = 0.7
    bpl_alpha1: float = 0.7
    bpl_alpha2: float = 1.5
    bpl_break: float = 1e41  # erg
    sigma: float = 0.1  # rad
    theta_p: float = 0.3  # rad
    gamma_p: float = 300.0
    zeta: float = 1.7
    theta_b_max: float = np.pi / 2
    n_gauss: int = 24
    lng_step: float = 0.1
    n_energies: int = 600
    n_bursts: int = 2_000_000
    n_sim: int = 100_000
    r_max: float = np.pi
    xlim: tuple = (32, 43)
    xticks: tuple = (32, 36, 40)
    ek_iso: float = 5e53  # erg
    eta: float = 0.15
    theta_max_frac: float = 1e-3
